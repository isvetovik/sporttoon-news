import Link from 'next/link';
import { useTranslation } from 'next-i18next';
import { useEffect, useState } from 'react';
import axios from 'axios';

export default function Home() {
  const { t } = useTranslation('common');
  const [news, setNews] = useState([]);

  useEffect(() => {
    async function fetchNews() {
      try {
        const response = await axios.get('/api/news');
        setNews(response.data);
      } catch (error) {
        console.error('Error fetching news:', error);
      }
    }
    fetchNews();
  }, []);

  return (
    <div className="min-h-screen bg-[#fef3e2]">
      <header className="bg-blue-600 text-white p-4 flex justify-between items-center">
        <h1 className="text-3xl font-bold">SportToon</h1>
        <div className="flex gap-4">
          <button className="bg-yellow-400 px-4 py-2 rounded-lg font-bold">{t('login')}</button>
          <button className="bg-orange-500 px-4 py-2 rounded-lg font-bold">{t('register')}</button>
        </div>
      </header>

      <nav className="flex overflow-x-auto bg-white p-4 gap-4 shadow-md">
        <button className="bg-yellow-300 px-3 py-1 rounded-full">Soccer</button>
        <button>Basketball</button>
        <button>Tennis</button>
        <button>American Football</button>
        <button>More</button>
      </nav>

      <main className="p-6">
        <section className="mb-8">
          <div className="bg-white shadow-lg rounded-lg p-6 flex items-center gap-4">
            <div className="flex-1">
              <h2 className="text-2xl font-extrabold">RONALDO SCORES EPIC WIN!</h2>
            </div>
            <div className="w-32 h-32 bg-blue-200 rounded-full"></div>
          </div>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-bold mb-4">Top Stories</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {news.slice(0, 4).map((item) => (
              <div key={item.title} className="bg-white p-4 rounded-lg shadow-md hover:scale-105 transition-transform">
                <div className="w-full h-24 bg-blue-100 mb-2 rounded"></div>
                <h3 className="font-bold text-lg mb-1">{item.title}</h3>
                <p className="text-sm">{item.description}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-bold mb-4">Latest News</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {news.slice(4, 10).map((item) => (
              <div key={item.title} className="bg-white p-4 rounded-lg shadow-md hover:scale-105 transition-transform">
                <div className="w-full h-40 bg-orange-100 mb-2 rounded relative">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="bg-white rounded-full p-2">
                      ▶
                    </div>
                  </div>
                </div>
                <h3 className="font-bold text-lg mb-1">{item.title}</h3>
                <p className="text-sm">{item.description}</p>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}