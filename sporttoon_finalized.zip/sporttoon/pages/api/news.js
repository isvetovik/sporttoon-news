import Parser from 'rss-parser';

const parser = new Parser();

const feeds = [
  'https://www.espn.com/espn/rss/news',
  'https://feeds.bbci.co.uk/sport/rss.xml',
  'https://www.skysports.com/rss/12040',
  'https://sports.yahoo.com/mlb/rss.xml',
  'https://www.nba.com/rss/nba_rss.xml',
  'https://www.nfl.com/rss/rsslanding?searchString=home',
  'https://www.motorsport.com/rss/f1/news/',
  'https://www.atptour.com/en/media/rss-feed',
  'https://www.wtatennis.com/rss.xml',
  'https://www.boxingscene.com/rss',
  'https://www.mmafighting.com/rss',
  'https://www.cyclingnews.com/rss',
  'https://swimswam.com/feed/',
  'https://www.biatlon.com/rss',
  'https://snookerhq.com/feed/',
  'https://volleyballworld.com/rss',
  'https://tabletennis.guide/rss',
  'https://theboardr.com/rss/skateboarding',
  'https://www.olympic.org/news/rss',
  'https://sports.inquirer.net/feed'
];

export default async function handler(req, res) {
  try {
    const allFeeds = await Promise.all(
      feeds.map(async (url) => {
        const feed = await parser.parseURL(url);
        return feed.items.map(item => ({
          title: item.title,
          link: item.link,
          description: item.contentSnippet || item.summary || '',
        }));
      })
    );

    const mergedFeeds = allFeeds.flat().slice(0, 30);
    res.status(200).json(mergedFeeds);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching news' });
  }
}